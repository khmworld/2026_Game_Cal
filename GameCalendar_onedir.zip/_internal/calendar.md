﻿# 2026 게임/시즌/이벤트 캘린더 (KST 기준)
- 표기 규칙: **[확정]** = 날짜가 공개된 항목 / **[예상]** = “대략 날짜(범위)”가 공개·추정 가능한 항목
- 포맷(표 컬럼): 날짜 | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL

---

## 2월 (February 2026)

| 날짜(또는 범위) | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL |
|---|---|---|---|---|---|---|
| 2026-02-03 ~ 2026-02-10 | **[확정]** | 🧪 | 디아블로 IV PTR 2.6.0 | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://news.blizzard.com/en-us/article/24247516/the-2-6-0-ptr-what-you-need-to-know |
| 2026-02-05 ~ 2026-02-09 | **[확정]** | ⌨️ | 스팀 타이핑 페스트 | PC | 행사 | https://steamcommunity.com/groups/steamworks/announcements/detail/493837645658461608 |
| 2026-02-09 ~ 2026-02-16 | **[확정]** | ⚔️ | 스팀 PvP 페스트 | PC | 행사 | https://steamcommunity.com/groups/steamworks/announcements/detail/493837645658461608 |
| 2026-02-11 09:00 PT | **[확정]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 12 종료 | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-02-19 ~ 2026-02-23 | **[확정]** | 🐴 | 스팀 호스 페스트 | PC | 행사 | https://steamcommunity.com/groups/steamworks/announcements/detail/493837645658461608 |
| 2026-02-20 17:00 PST | **[확정]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 13 시작 | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-02-23 ~ 2026-03-02 | **[확정]** | 🧪 | 스팀 넥스트 페스트 2월 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events/nextfest/2026february |
| 2026-02-23 ~ 2026-03-02 | **[확정]** | 🧪 | 스팀 넥스트 페스트 2월(스토어 안내) | PC | 행사 | https://store.steampowered.com/sale/nextfest |
| 2026-02-27 | **[예상]** | 🗓️ | 2026년 신작(2월 말) 체크포인트(대작/인디 포함) | All | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-02 (말) | **[예상]** | 🔥 | 디아블로 IV 시즌 11 진행(2월 구간) | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://diablo4.blizzard.com/season |

---

## 3월 (March 2026)

| 날짜(또는 범위) | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL |
|---|---|---|---|---|---|---|
| 2026-03-09 ~ 2026-03-16 | **[확정]** | 🏰 | 스팀 타워 디펜스 페스트 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-03-10 | **[확정]** | 🔥 | 디아블로 IV 시즌 11 종료 | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://www.arpg-timeline.com/game/diablo-iv |
| 2026-03-10 | **[확정]** | 🔥 | 디아블로 IV 시즌 12 시작 | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://www.arpg-timeline.com/game/diablo-iv |
| 2026-03-19 ~ 2026-03-26 | **[확정]** | 🛍️ | 스팀 봄 세일 2026 | PC | 행사 | https://steamcommunity.com/groups/steamworks/announcements/detail/532102384016426892 |
| 2026-03-19 ~ 2026-03-26 | **[확정]** | 🛍️ | 스팀 봄 세일(가이드/정리) | PC | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |
| 2026-03 (중) | **[예상]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 13 진행(3월 구간) | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-03 (중) | **[예상]** | 🎮 | 2026년 신작(3월) 체크포인트(턴제/액션/스토리) | All | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-03 (중) | **[예상]** | 🎮 | 닌텐도/포켓몬 라인업 체크포인트(발표/업데이트) | Nintendo | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |
| 2026-03 (말) | **[예상]** | ⚙️ | 패스 오브 엑자일 2 시즌/리그 공지 체크포인트 | PC/PS5/XSX\|S | 시즌 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-03 (말) | **[예상]** | 🔥 | 디아블로 IV 시즌 12 초반 메타 정착 구간 | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://diablo4.blizzard.com/season |

---

## 4월 (April 2026)

| 날짜(또는 범위) | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL |
|---|---|---|---|---|---|---|
| 2026-04-09 ~ 2026-04-13 | **[확정]** | 🔎 | 스팀 히든 오브젝트 페스트 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-04-20 ~ 2026-04-27 | **[확정]** | 🏰 | 스팀 미디벌 페스트 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-04-28 | **[확정]** | 🩸 | 디아블로 IV 확장팩: 로드 오브 헤이트리드 | PC/PS5/PS4/XSX\|S/XBO | 확장팩 | https://www.pcgamer.com/games/rpg/diablo-4s-second-new-class-is-a-summoner-who-commands-demons-to-fight-demons/ |
| 2026-04-28 | **[확정]** | 🩸 | 디아블로 IV 확장팩(보도 요약) | PC/PS5/PS4/XSX\|S/XBO | 확장팩 | https://www.techradar.com/gaming/a-surprise-diablo-2-resurrected-dlc-adds-warlock-the-first-new-class-the-game-has-had-in-25-years-with-diablo-4-and-diablo-immortal-also-expected-to-receive-it-this-year |
| 2026-04 (중) | **[예상]** | 🔥 | 디아블로 IV 시즌 12 중반 구간 | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://diablo4.blizzard.com/season |
| 2026-04 (중) | **[예상]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 13 중반 구간 | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-04 (말) | **[예상]** | 🎮 | 2026년 신작(4월) 체크포인트 | All | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-04 (말) | **[예상]** | ⚙️ | 패스 오브 엑자일 2 시즌/리그 운영 체크포인트 | PC/PS5/XSX\|S | 시즌 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-04 (말) | **[예상]** | 🧪 | 스팀 “다음 넥스트 페스트/세일” 대비 데모 찜목록 정리 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-04 (말) | **[예상]** | 🎮 | 닌텐도/포켓몬(봄) 업데이트·이벤트 체크 | Nintendo | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |

---

## 5월 (May 2026)

| 날짜(또는 범위) | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL |
|---|---|---|---|---|---|---|
| 2026-05 (초) | **[예상]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 13 후반 진입 | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-05 (중) | **[예상]** | 🔥 | 디아블로 IV 시즌 12 후반(확장팩 전환 준비) | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://diablo4.blizzard.com/season |
| 2026-05 (중) | **[예상]** | 🎮 | 2026년 신작(5월) 체크포인트 | All | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-05 (중) | **[예상]** | 🎮 | 닌텐도/포켓몬(초여름) 이벤트 체크포인트 | Nintendo | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |
| 2026-05 (말) | **[예상]** | 🛍️ | 스팀 “대형 세일 전” 찜목록 정리 주간 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-05 (말) | **[예상]** | ⚙️ | 패스 오브 엑자일 2 시즌/리그 공지 창(전후) | PC/PS5/XSX\|S | 시즌 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-05 (말) | **[예상]** | 🎮 | (턴제/전술) 인디·데모 집중 플레이(33원정대 취향 라인) | PC | 턴제/전술 | https://store.steampowered.com/sale/nextfest |
| 2026-05 (말) | **[예상]** | 🎯 | 콘솔(PS/Xbox) 월간 할인 체크포인트 | PS5/XSX\|S | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-05 (말) | **[예상]** | 🎮 | AAA 출시 라인업(5월) 체크포인트 | All | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-05 (말) | **[예상]** | 🧠 | 스토리·선택지 게임(서사형) 월간 체크포인트 | All | 어드벤처 | https://www.pcgamer.com/games/new-pc-games-2026/ |

---

## 6월 (June 2026)

| 날짜(또는 범위) | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL |
|---|---|---|---|---|---|---|
| 2026-06-05 | **[확정]** | 🎤 | 서머 게임 페스트 2026(메인 쇼) | All | 행사 | https://www.summergamefest.com/ |
| 2026-06-05 | **[확정]** | 🎤 | 서머 게임 페스트 2026(보도) | All | 행사 | https://www.gamespot.com/articles/summer-game-fest-2026-announced-for-june-2026/1100-6535415/ |
| 2026-06-15 ~ 2026-06-22 | **[확정]** | 🧪 | 스팀 넥스트 페스트 6월(해당 에디션은 스팀 일정 공지 기준) | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-06 (중) | **[예상]** | 🔥 | 디아블로 IV 확장팩 이후 시즌/패치 안정화 구간 | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://diablo4.blizzard.com/season |
| 2026-06 (중) | **[예상]** | ⚙️ | 패스 오브 엑자일 2 시즌/리그 티저 체크포인트 | PC/PS5/XSX\|S | 시즌 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-06 (중) | **[예상]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 14(전환 가능 창) | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-06 (말) | **[예상]** | 🛍️ | 스팀 여름 세일(전후) 대비 체크포인트 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-06 (말) | **[예상]** | 🎮 | 닌텐도 다이렉트(여름) 가능 창 | Nintendo | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |
| 2026-06 (말) | **[예상]** | 🎮 | 2026년 신작(6월) 체크포인트 | All | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-06 (말) | **[예상]** | 🧠 | 턴제/전술 인디(Next Fest 연계) 집중 주간 | PC | 턴제/전술 | https://store.steampowered.com/sale/nextfest |

---

## 7월 (July 2026)

| 날짜(또는 범위) | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL |
|---|---|---|---|---|---|---|
| 2026-07 (초) | **[예상]** | 🔥 | 디아블로 IV 시즌 전환 체크포인트(확장팩 이후 첫 시즌 가능) | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://diablo4.blizzard.com/season |
| 2026-07 (초) | **[예상]** | ⚙️ | 패스 오브 엑자일 2 시즌/리그 시작 가능 창 | PC/PS5/XSX\|S | 시즌 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-07 (중) | **[예상]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 14 진행 구간 | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-07 (중) | **[예상]** | 🛍️ | 스팀 여름 세일(해당 연도 일정은 스팀 공지 기준) | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-07 (중) | **[예상]** | 🎮 | 2026년 신작(7월) 체크포인트 | All | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-07 (말) | **[예상]** | 🎮 | 닌텐도/포켓몬 여름 이벤트 체크포인트 | Nintendo | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |
| 2026-07 (말) | **[예상]** | 🎯 | 콘솔(PS/Xbox) 구독/패스 월간 점검 | PS5/XSX\|S | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-07 (말) | **[예상]** | 🧠 | 스토리·선택지 게임(서사형) 월간 체크포인트 | All | 어드벤처 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-07 (말) | **[예상]** | ⚔️ | 액션RPG(하드코어 포함) 월간 체크포인트 | All | 액션RPG | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-07 (말) | **[예상]** | 🕹️ | 인디/야겜 포함(스팀) 신작 탐색 주간 | PC | 행사 | https://store.steampowered.com/sale/nextfest |

---

## 8월 (August 2026)

| 날짜(또는 범위) | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL |
|---|---|---|---|---|---|---|
| 2026-08-26 ~ 2026-08-30 | **[확정]** | 🎪 | 게임스컴 2026 | All | 행사 | https://www.cologne-tourism.com/experiences-lifestyle/events/detail/gamescom |
| 2026-08-26 (전후) | **[확정]** | 🎪 | 게임스컴(위키 요약) | All | 행사 | https://en.wikipedia.org/wiki/Gamescom |
| 2026-08 (중) | **[예상]** | 🔥 | 디아블로 IV 시즌 진행(8월 구간) | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://diablo4.blizzard.com/season |
| 2026-08 (중) | **[예상]** | ⚙️ | 패스 오브 엑자일 2 시즌/리그(8월 구간) | PC/PS5/XSX\|S | 시즌 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-08 (중) | **[예상]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 14 후반 | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-08 (말) | **[예상]** | 🛍️ | 스팀(8월) 테마 페스트 체크포인트 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-08 (말) | **[예상]** | 🎮 | 2026년 신작(8월) 체크포인트 | All | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-08 (말) | **[예상]** | 🎮 | 닌텐도/포켓몬(여름말) 이벤트 체크 | Nintendo | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |
| 2026-08 (말) | **[예상]** | 🧠 | 턴제/전술(인디) 월간 체크포인트 | PC/NS | 턴제/전술 | https://store.steampowered.com/sale/nextfest |
| 2026-08 (말) | **[예상]** | 🎯 | 콘솔(PS/Xbox) 하반기 대작 대비 점검 | PS5/XSX\|S | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |

---

## 9월 (September 2026)

| 날짜(또는 범위) | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL |
|---|---|---|---|---|---|---|
| 2026-09 (초) | **[예상]** | 🔥 | 디아블로 IV 시즌 전환 가능 창(9월 구간) | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://diablo4.blizzard.com/season |
| 2026-09 (초) | **[예상]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 15 시작 가능 창 | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-09 (중) | **[예상]** | ⚙️ | 패스 오브 엑자일 2 시즌 후반(9월 구간) | PC/PS5/XSX\|S | 시즌 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-09 (중) | **[예상]** | 🛍️ | 스팀(9월) 테마 페스트 체크포인트 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-09 (말) | **[예상]** | 🎮 | 닌텐도 다이렉트(가을) 가능 창 | Nintendo | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |
| 2026-09 (말) | **[예상]** | 🎮 | 2026년 신작(9월) 체크포인트 | All | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-09 (말) | **[예상]** | 🧠 | 턴제/전술(신작/인디) 월간 체크포인트 | PC/NS | 턴제/전술 | https://store.steampowered.com/sale/nextfest |
| 2026-09 (말) | **[예상]** | ⚔️ | 액션RPG(대작/하드코어) 월간 체크포인트 | All | 액션RPG | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-09 (말) | **[예상]** | 🎯 | 연말 대작 대비 “백로그 컷” 주간 | All | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-09 (말) | **[예상]** | 🎮 | 포켓몬/닌텐도 온라인 이벤트(가을 시작) 체크 | Nintendo | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |

---

## 10월 (October 2026)

| 날짜(또는 범위) | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL |
|---|---|---|---|---|---|---|
| 2026-10 (초) | **[예상]** | 🔥 | 디아블로 IV 시즌(10월 구간) | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://diablo4.blizzard.com/season |
| 2026-10 (초) | **[예상]** | 🛍️ | 스팀(10월) 주요 세일/페스트 체크포인트 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-10 (중) | **[예상]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 15 중반 | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-10 (중) | **[예상]** | ⚙️ | 패스 오브 엑자일 2 시즌/리그 티저 가능 창 | PC/PS5/XSX\|S | 시즌 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-10 (중) | **[예상]** | 🎮 | 닌텐도/포켓몬 할로윈 시즌 이벤트 체크 | Nintendo | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |
| 2026-10 (말) | **[예상]** | 🎮 | 2026년 신작(10월) 체크포인트 | All | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-10 (말) | **[예상]** | 🎃 | 스팀 호러 시즌 쇼핑 체크포인트 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-10 (말) | **[예상]** | 🧠 | 턴제/전술(신작) 월간 체크포인트 | PC/NS | 턴제/전술 | https://store.steampowered.com/sale/nextfest |
| 2026-10 (말) | **[예상]** | ⚔️ | 액션 게임(근접/스타일리시) 월간 체크포인트 | All | 액션 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-10 (말) | **[예상]** | 🎯 | 콘솔 스토어(PS/Xbox) 할로윈 할인 체크 | PS5/XSX\|S | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |

---

## 11월 (November 2026)

| 날짜(또는 범위) | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL |
|---|---|---|---|---|---|---|
| 2026-11 (초) | **[예상]** | 🔥 | 디아블로 IV 시즌(11월 구간) | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://diablo4.blizzard.com/season |
| 2026-11 (초) | **[예상]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 15 후반 | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-11 (중) | **[예상]** | ⚙️ | 패스 오브 엑자일 2 시즌/리그 시작 가능 창 | PC/PS5/XSX\|S | 시즌 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-11 (중) | **[예상]** | 🛍️ | 블랙프라이데이 세일 주간(플랫폼 전반) | PC/PS/Xbox/Nintendo | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-11 (말) | **[예상]** | 🎮 | 닌텐도/포켓몬 연말 이벤트 시작 체크 | Nintendo | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |
| 2026-11 (말) | **[예상]** | 🎮 | 2026년 신작(11월) 체크포인트 | All | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-11 (말) | **[예상]** | 🧠 | 턴제/전술·인디 세일 집중 구간 | PC | 턴제/전술 | https://store.steampowered.com/sale/nextfest |
| 2026-11 (말) | **[예상]** | ⚔️ | 액션RPG(연말 메타) 체크포인트 | All | 액션RPG | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-11 (말) | **[예상]** | 🎯 | 연말 대작 대비 “백로그 컷” 주간 | All | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-11 (말) | **[예상]** | 🎮 | 콘솔(PS/Xbox) 연말 라인업 점검 | PS5/XSX\|S | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |

---

## 12월 (December 2026)

| 날짜(또는 범위) | 구분 | 이모지 | 한글명 | 플랫폼 | 장르 | URL |
|---|---|---|---|---|---|---|
| 2026-12-10 | **[확정]** | 🏆 | 더 게임 어워즈 2026 | All | 행사 | https://thegameawards.com/faq |
| 2026-12 (초) | **[예상]** | 🪜 | 디아블로 II: 레저렉션 래더 시즌 16 시작 가능 창 | PC/PS/Xbox/Switch | 시즌 | https://news.blizzard.com/en-us/article/24246296/diablo-ii-resurrected-ladder-season-13-coming-soon |
| 2026-12 (초) | **[예상]** | 🔥 | 디아블로 IV 시즌(12월 구간) | PC/PS5/PS4/XSX\|S/XBO | 시즌 | https://diablo4.blizzard.com/season |
| 2026-12 (중) | **[예상]** | ⚙️ | 패스 오브 엑자일 2 시즌 중반 이벤트 가능 창 | PC/PS5/XSX\|S | 시즌 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-12-17 ~ 2027-01-04 | **[예상]** | 🎁 | 스팀 겨울 세일(연말 대형 세일) | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-12 (중) | **[예상]** | 🎮 | 닌텐도/포켓몬 연말 이벤트 체크 | Nintendo | 행사 | https://www.gamesradar.com/games/steam-next-fest-guide/ |
| 2026-12 (말) | **[예상]** | 🎯 | 스팀 겨울 세일 찜목록 최종 구매 체크 | PC | 행사 | https://partner.steamgames.com/doc/marketing/upcoming_events |
| 2026-12 (말) | **[예상]** | 🧠 | 턴제/전술·인디 연말 정주행 구간 | PC/NS | 턴제/전술 | https://store.steampowered.com/sale/nextfest |
| 2026-12 (말) | **[예상]** | 🎮 | 콘솔 스토어(PS/Xbox) 연말 세일 집중 | PS5/XSX\|S | 행사 | https://www.pcgamer.com/games/new-pc-games-2026/ |
| 2026-12-31 | **[예상]** | 🎆 | 시즌제 게임 연말 마감 러시(이벤트 종료/보상) | All | 시즌 | https://diablo4.blizzard.com/season |
